﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace Energia_Incidente_1
{
    public partial class Form1 : Form
    {
        Excel.Application app = new Excel.Application();                                //cria instância que permite a interação do C# com Excel.
        Workbook pastaarquivo, pasta_calculossalvos;                                    //nomes das planilhas dentro deste programa
        Worksheet Table1, Table2, Table3, Table4, Table5, Table6, Table7, Table8, Table10, Table11, Table12, Plan1;
       

        String path = @"C:\INICIO_EI\Energia_Incidente_1\Tabelas-IEEE-1584-2018-e-OSHA";      //local da planilha com as tabelas da IEEE 1584/2018 e OSHA
                                                                                              //C:\INICIO_EI\Energia_Incidente_1

        String arquivo = @"C:\INICIO_EI\Energia_Incidente_1\Calculos_Salvos"; //local da planilha de salvamento

        public Form1()
        {
            InitializeComponent();
           
        }

        private void bCalcula_Click(object sender, EventArgs e)
        {
            CarregarPlanilha1();

            try
            {
                string Nome = tBNome.Text;
                string AC_DC = cBtpcorrente.Text;
                float Voc = float.Parse(tBVoc.Text);
                string Config = cBConfig.Text;
                float Ibf = float.Parse(tBIbf.Text);
                float Gap = float.Parse("0"+tBG.Text);
                float Disttrab = float.Parse("0" + tBD.Text);
                float Larg = float.Parse("0" + tBLargura.Text);
                float Alt = float.Parse("0" + tBAltura.Text);
                float Prof = float.Parse("0"+tBProfundidade.Text);
                float TIarc = float.Parse("0"+tBTiarc.Text);
                float TIarcmin = float.Parse("0"+tBTIarcmin.Text);
                string Ambiente = cBAmbiente.Text;


                Circuito novo_Circuito = new Circuito(Voc, Config, Ibf, Gap, Disttrab, Larg, Alt, Prof, Nome);

                //Antes de exibir o novo resultado, limpa os campos com os resultados anteriores:
                tBIarc.Text = "  ";
                tBIarcmin.Text = "  ";
                tBEI.Text = "  ";
                tBAFB.Text = "   ";
                

                
                if (Voc>0.203 && Voc<0.601 && AC_DC =="AC")
                {
                    Metodo1IEEE(novo_Circuito, TIarc, TIarcmin);
                }
                if (Voc > 0.600 && Voc <= 15 && AC_DC == "AC")
                {
                    // Calcula pelo método2
                    Metodo2IEEE(novo_Circuito, TIarc, TIarcmin);
                }

                if (AC_DC == "CC")
                {
                    //Método de DOAN
                    MetodoDOAN(novo_Circuito, TIarc, Ambiente);
                }

                if (Voc > 15 && Voc < 800 && AC_DC == "AC")
                {
                    MetodoOSHA(novo_Circuito, TIarc, Ambiente);
                }

                if (float.Parse("0" + tBEI.Text) != 0)
                {
                    ATPVselecao();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha: " + ex.Message);
            }

            if (pastaarquivo != null)                  //verifica qse o arquivo esta aberto
                pastaarquivo.Close(true);              // se estiver aberto fecha
        }

        private void bSalvar_Click(object sender, EventArgs e)
        {
           

            CarregarPlanilha2();

            //verificar ultima linha preenchida para inserir o próximo calculo na próxima linha.

            int row = 0; // Começa a partir da linha 2

            // Loop para encontrar a primeira linha vazia na coluna B (coluna 2)
            while (Plan1.Cells[row+2, 2].Value != null && !string.IsNullOrEmpty(Plan1.Cells[row+2, 2].Value.ToString()))
            {
                row++; // Incrementa a linha se a atual estiver preenchida
            }

            // Quando encontra a linha vazia, insere o valor do tBNome.Text
            Plan1.Cells[row + 2, 1].Value = row;
            Plan1.Cells[row + 2, 2].Value = tBNome.Text;
            Plan1.Cells[row + 2, 3].Value = cBtpcorrente.Text;
            Plan1.Cells[row + 2, 4].Value = float.Parse("0" + tBVoc.Text);
            Plan1.Cells[row + 2, 5].Value = cBConfig.Text;
            Plan1.Cells[row + 2, 6].Value = float.Parse("0" + tBIbf.Text);
            Plan1.Cells[row + 2, 7].Value = float.Parse("0" + tBG.Text);
            Plan1.Cells[row + 2, 8].Value = float.Parse("0" + tBD.Text);
            Plan1.Cells[row + 2, 9].Value = tBLargura.Text;
            Plan1.Cells[row + 2, 10].Value = tBAltura.Text;
            Plan1.Cells[row + 2, 11].Value = tBProfundidade.Text;
            Plan1.Cells[row + 2, 12].Value = float.Parse("0" + tBTiarc.Text);
            Plan1.Cells[row + 2, 13].Value = float.Parse("0" + tBTIarcmin.Text);
            Plan1.Cells[row + 2, 14].Value = float.Parse("0" + tBIarc.Text);
            Plan1.Cells[row + 2, 15].Value = float.Parse("0" + tBIarcmin.Text);
            Plan1.Cells[row + 2, 16].Value = float.Parse("0" + tBEI.Text);
            Plan1.Cells[row + 2, 17].Value = float.Parse("0" + tBAFB.Text);

            pasta_calculossalvos.Save();

            MessageBox.Show("Informações Salvas!!","Aviso");


            if (pasta_calculossalvos != null)                  //verifica qse o arquivo esta aberto
                pasta_calculossalvos.Close(true);              // se estiver aberto fecha
        }

        // Esta função o Método 1 definido pela IEEE:
        public void Metodo1IEEE(Circuito novo_Circuito, float TIarc, float TIarcmin)
        {
            double Iarc_600_calculado = Iarc_Voc(novo_Circuito, 600);
            double Iarc_calculado = IarcMetd1(novo_Circuito, Iarc_600_calculado);
            
            // Exibe na Text Box o Iarc final
            tBIarc.Text = Iarc_calculado.ToString();

            //Verifica se o invólucro é do tipo raso:1 ou típico:2
            int Tipo_involucro = Verifica_Tipo(novo_Circuito);

            // Calcula o fator de correção:
            double CF = Calcula_Fator_Correcao(novo_Circuito, Tipo_involucro);

            //Calcula a energia incidente Intermediaria (também é a final)
            double EImV600 = Calcula_EImV600(TIarc, novo_Circuito, Iarc_600_calculado, Iarc_calculado, CF);

            //Calcula a Distancia Segura de Aproximação (também é a final)
            double AFBmV600 = Calcula_AFBmV600(TIarc, novo_Circuito, Iarc_600_calculado, Iarc_calculado, CF);

            //Calcula Iarcmin
            double Iarcmin_calculado = Iarcmin(novo_Circuito, Iarc_calculado);
            // Exibe na Text Box o Iarc reduzido
            tBIarcmin.Text = Iarcmin_calculado.ToString();

            //Nova Energia Incidente com o Iarc reduzido
            double EIm2V600 = Calcula_EImV600(TIarcmin, novo_Circuito, Iarc_600_calculado, Iarcmin_calculado, CF);
            //MessageBox.Show("Energia Incidente Final: " + EIm2V600 +" J/cm²");

            //Calcula a nova distancia Segura de Aproximação para Iarc reduzido(também é a final)
            double AFBm2V600 = Calcula_AFBmV600(TIarcmin, novo_Circuito, Iarc_600_calculado, Iarcmin_calculado, CF);

            //MessageBox.Show("Energia Incidente Final: " + EIm2V600/4.184 + " Cal/cm²  \n" +"Distancia segura de aproximação Final: " + AFBm2V600 + " mm" + "Energia Incidente Intermediaria: " + EImV600/4.184 + " Cal/cm²  \n");

            if (EIm2V600 > EImV600)
            {
                tBEI.Text = (EIm2V600 / 4.184).ToString();
            }
            else
            {
                tBEI.Text = (EImV600 / 4.184).ToString();
            }

            if (AFBm2V600 > AFBmV600)
            {
                tBAFB.Text = AFBm2V600.ToString();
            }
            else
            {
                tBAFB.Text = AFBmV600.ToString();
            }

        }

        public void Metodo2IEEE(Circuito novo_Circuito, float TIarc, float TIarcmin)
        {
            double Iarc_600_calculado = Iarc_Voc(novo_Circuito, 600);
            double Iarc_2700_calculado = Iarc_Voc(novo_Circuito, 2700);
            double Iarc_14300_calculado = Iarc_Voc(novo_Circuito, 14300);

            double Iarc_calculado = IarcMetd2(novo_Circuito, Iarc_600_calculado, Iarc_2700_calculado, Iarc_14300_calculado);
            // Exibe na Text Box o Iarc final
            tBIarc.Text = Iarc_calculado.ToString();

            //Invólucro é do tipo  típico:2 pois Voc é maior que 600 Vca
            int Tipo_involucro = 2;

            // Calcula o fator de correção:
            double CF = Calcula_Fator_Correcao(novo_Circuito, Tipo_involucro);

            //Calcula a energia incidente Intermediaria para V=600V
            double EImV600 = Calcula_EImV600(TIarc, novo_Circuito, Iarc_600_calculado, Iarc_600_calculado, CF);

            //Calcula a energia incidente Intermediaria para V=2700V
            double EImV2700 = Calcula_EImV2700(TIarc, novo_Circuito, Iarc_2700_calculado, CF);

            //Calcula a energia incidente Intermediaria para V=14700V
            double EImV14300 = Calcula_EImV14300(TIarc, novo_Circuito, Iarc_14300_calculado, CF);
            
            //Calcula o valor final da EI
            double EI = Calcula_EI(novo_Circuito, EImV600, EImV2700, EImV14300);

            //Calcula a Distancia Segura de Aproximação (para V=600)
            double AFBmV600 = Calcula_AFBmV600(TIarc, novo_Circuito, Iarc_600_calculado, Iarc_600_calculado, CF);
            //MessageBox.Show("AFB 600V " + AFBmV600 + " mm");

            //Calcula a Distancia Segura de Aproximação (para V=2700)
            double AFBmV2700 = Calcula_AFBmV2700(TIarc, novo_Circuito, Iarc_2700_calculado, CF);

            //Calcula a Distancia Segura de Aproximação (para V=14300)
            double AFBmV14300 = Calcula_AFBmV14300(TIarc, novo_Circuito, Iarc_14300_calculado, CF);

            //Calcula o valor final da AFB
            double AFB = Calcula_AFB(novo_Circuito, AFBmV600, AFBmV2700, AFBmV14300);

            //Calcula Iarc_600_min
            double Iarc_600_min_calculado = Iarcmin(novo_Circuito, Iarc_600_calculado);

            //Calcula Iarc_2700_min
            double Iarc_2700_min_calculado = Iarcmin(novo_Circuito, Iarc_2700_calculado);

            //Calcula Iarc_14300_min
            double Iarc_14300_min_calculado = Iarcmin(novo_Circuito, Iarc_14300_calculado);

            //Calcula Iarc_min
            double Iarc_min_calculado = IarcMetd2(novo_Circuito, Iarc_600_min_calculado, Iarc_2700_min_calculado, Iarc_14300_min_calculado);
                       
            // Exibe na Text Box o Iarc reduzido
            tBIarcmin.Text = Iarc_min_calculado.ToString();

            //Calcula a energia incidente Intermediaria para V=600V
            double EIV600 = Calcula_EImV600(TIarcmin, novo_Circuito, Iarc_600_min_calculado, Iarc_600_min_calculado, CF);

            //Calcula a energia incidente Intermediaria para V=2700V
            double EIV2700 = Calcula_EImV2700(TIarcmin, novo_Circuito, Iarc_2700_min_calculado, CF);

            //Calcula a energia incidente Intermediaria para V=14700V
            double EIV14300 = Calcula_EImV14300(TIarcmin, novo_Circuito, Iarc_14300_min_calculado, CF);

            //Calcula o valor final da EI para Iarcmin
            double EImin = Calcula_EI(novo_Circuito, EIV600, EIV2700, EIV14300);

            //Calcula a Distancia Segura de Aproximação (para V=600) para Iarcmin
            double AFBV600 = Calcula_AFBmV600(TIarcmin, novo_Circuito, Iarc_600_min_calculado, Iarc_600_min_calculado, CF);
           
            //Calcula a Distancia Segura de Aproximação (para V=2700) para Iarcmin
            double AFBV2700 = Calcula_AFBmV2700(TIarcmin, novo_Circuito, Iarc_2700_min_calculado, CF);

            //Calcula a Distancia Segura de Aproximação (para V=14300) para Iarcmin
            double AFBV14300 = Calcula_AFBmV14300(TIarcmin, novo_Circuito, Iarc_14300_min_calculado, CF);

            //Calcula o valor final da AFB para Iarcmin
            double AFBmin = Calcula_AFB(novo_Circuito, AFBV600, AFBV2700, AFBV14300);


            if (EI > EImin)
            {
                tBEI.Text = (EI / 4.184).ToString();
            }
            else
            {
                tBEI.Text = (EImin / 4.184).ToString();
            }

            if (AFB > AFBmin)
            {
                tBAFB.Text = AFB.ToString();
            }
            else
            {
                tBAFB.Text = AFBmin.ToString();
            }
        }

        // Esta função o Método de DOAN apresentado em artigo na IEEE:
        public void MetodoDOAN(Circuito novo_circuito, float TIarc, string Ambiente)
        {
            float Rsistema;
            float Iarc;
            float EI;
            float DSA;
            float novoDSA=0;

            Rsistema = novo_circuito.Voc / novo_circuito.Ibf;       //Estima-se a resistencia do sistema com os valores de tensão e corrente de Curto franco
            Iarc = novo_circuito.Ibf * 1000 / 2;                    //Para Máxima Transferência de Potencia a Impedencia do sistema = arco, logo Iar=Ibf/2

            // Exibe na Text Box o Iarc
            tBIarc.Text = (Iarc/1000).ToString();

            //Calcula o EI
            if (novo_circuito.Distancia_trabalho != 0)
            {
                EI = 0.005F * (novo_circuito.Voc * 1000 * novo_circuito.Voc * 1000 / Rsistema) * 
                    ((TIarc / 1000) / (novo_circuito.Distancia_trabalho * novo_circuito.Distancia_trabalho / 100));

                if (Ambiente =="FECHADO")
                {
                    EI = EI * 3;
                }

                //Calcula a DSA por DOAN com EI=1,2
                float Base = 0.005F * (novo_circuito.Voc * 1000 * novo_circuito.Voc * 1000 / Rsistema) * TIarc / 1.2F;
                DSA = ((float)Math.Pow(Base, 0.5));


                // Calcula a DSA pela NFPA 70E 2024
                // Limitado a duração máxima de arco de 2 segundos
                // Vestuario exposto a eletrólito deve ser avaliado também quanto à proteção eletrolítica
                if (novo_circuito.Voc <= 0.6)
                {   if (novo_circuito.Ibf < 1.5)
                    { novoDSA = 900; }
                    else if (novo_circuito.Ibf < 3)         // else if (novo_circuito.Ibf < 3 && novo_circuito.Ibf >= 1.5)
                    { novoDSA = 1200; }
                    else if (novo_circuito.Ibf < 7)
                    { novoDSA = 1800; }
                    else if (novo_circuito.Ibf < 10)
                    { novoDSA = 2500; }
                    else
                    { novoDSA = 2500; }
                }
                if (novoDSA > DSA)
                {   DSA = novoDSA;  }
                
                // Exibe na Text Box a EI
                tBEI.Text = EI.ToString();
                // Exibe na Text Box a DSA
                tBAFB.Text = DSA.ToString();
            }
            else
            {   // Limpa a Text Box a EI
                tBEI.Text = "  ";
                // Limpa a Text Box a DSA
                tBAFB.Text = "  ";
            }
        }

        public void MetodoOSHA(Circuito novo_circuito, float TIarc, string Ambiente)
        {
            //Obs.: Inserir condições de erro, ou seja, condições fora da tabela;
            double EI=0, DSA=0;
            //Arcos Fase-Terra
            tBIarc.Text = novo_circuito.Ibf.ToString();

            if (TIarc != 0)
            {
                if (Ambiente == "ABERTO")
                {
                    for (int a = 5; a < 80; a++)
                    {
                        /* if (novo_circuito.Voc > Table11.Cells[a, 1].Value && novo_circuito.Voc <= Table11.Cells[a, 2].Value &&
                             novo_circuito.Distancia_trabalho >= Table11.Cells[a, 3].Value && novo_circuito.Ibf > Table11.Cells[a - 1, 5].Value &&
                             novo_circuito.Ibf <= Table11.Cells[a, 5].Value)*/
                        if (novo_circuito.Voc > Table11.Cells[a, 1].Value && novo_circuito.Voc <= Table11.Cells[a, 2].Value &&
                            5000 >= Table11.Cells[a, 3].Value && novo_circuito.Ibf > Table11.Cells[a - 1, 5].Value &&
                            novo_circuito.Ibf <= Table11.Cells[a, 5].Value)

                        {
                            for (int i = 7; i < 11; i++)
                            {
                                if (TIarc <= Table11.Cells[a, i].Value)
                                {
                                    EI = ((Table11.Cells[2, i].Value - Table11.Cells[2, i - 1].Value) / (Table11.Cells[a, i].Value - Table11.Cells[a, i - 1].Value)) * TIarc;
                                    DSA = Table11.Cells[a, 4].Value;
                                }

                            }
                        }
                    }
                }

                if (EI < 4)
                {
                    EI = 4;
                }

                // Exibe na Text Box a EI
                tBEI.Text = EI.ToString();

                // Exibe na Text Box a DSA
                tBAFB.Text = DSA.ToString();
            }

        }

        public double Iarc_Voc(Circuito novo_Circuito, int Voc)
        {
            double[] k = new double[11];
            double Iarc_Voc_calculado;
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6


            if (novo_Circuito.Configuracao == "VCB")
            {
                for (int a = 2; a < 5; a++)
                {
                    if (Voc == Table1.Cells[a, 2].Value)
                    {
                        for (int i = 1; i < k.Length; i++)
                        {
                            k[i] = Table1.Cells[a, 2 + i].Value;
                        }
                    }
                }
            }
            if (novo_Circuito.Configuracao == "VCBB")
            {
                for (int a = 5; a < 8; a++)
                {
                    if (Voc == Table1.Cells[a, 2].Value)
                    {
                        for (int i = 1; i < k.Length; i++)
                        {
                            k[i] = Table1.Cells[a, 2 + i].Value;
                        }
                    }
                }
            }
            if (novo_Circuito.Configuracao == "HCB")
            {
                for (int a = 8; a < 11; a++)
                {
                    if (Voc == Table1.Cells[a, 2].Value)
                    {
                        for (int i = 1; i < k.Length; i++)
                        {
                            k[i] = Table1.Cells[a, 2 + i].Value;
                        }
                    }
                }
            }
            if (novo_Circuito.Configuracao == "VOA")
            {
                for (int a = 11; a < 14; a++)
                {
                    if (Voc == Table1.Cells[a, 2].Value)
                    {
                        for (int i = 1; i < k.Length; i++)
                        {
                            k[i] = Table1.Cells[a, 2 + i].Value;
                        }
                    }
                }
            }
            if (novo_Circuito.Configuracao == "HOA")
            {
                for (int a = 14; a < 17; a++)
                {
                    if (Voc == Table1.Cells[a, 2].Value)
                    {
                        for (int i = 1; i < k.Length; i++)
                        {
                            k[i] = Table1.Cells[a, 2 + i].Value;
                        }
                    }
                }
            }

            Iarc_Voc_calculado = (Math.Pow(10, (k[1]+(k[2]*Math.Log10(Ibf))+(k[3]*Math.Log10(novo_Circuito.Gap))))) * ((k[4] * Ibf6) + (k[5] * Ibf5) + (k[6] * Ibf4) + (k[7] * Ibf3) + (k[8] * Ibf2) + (k[9] * Ibf)+k[10]);
            return (Iarc_Voc_calculado);
        }

        public double IarcMetd1(Circuito novo_Circuito, double Iarc_600_calculado)
        {
            double Iarc;
            double DENOMINADOR;
            double Voc2 = novo_Circuito.Voc * novo_Circuito.Voc;
            double Iarc_600_2 = Iarc_600_calculado * Iarc_600_calculado;
            double Ibf2 = novo_Circuito.Ibf * novo_Circuito.Ibf;
            double A = 0.6 * 0.6;

            DENOMINADOR = (A / Voc2) * ((1 / Iarc_600_2) - ((A - Voc2) / (A * Ibf2)));

            Iarc = 1 / (Math.Pow(DENOMINADOR, 0.5));
                                 
            return (Iarc);
        }

        public double IarcMetd2(Circuito novo_Circuito, double Iarc_600_calculado, double Iarc_2700_calculado, double Iarc_14300_calculado)
        {
            double Iarc=0;
            double Iarc_1, Iarc_2, Iarc_3;

            Iarc_1 = (((Iarc_2700_calculado - Iarc_600_calculado) / 2.1) * (novo_Circuito.Voc - 2.7)) + Iarc_2700_calculado;

            Iarc_2 = (((Iarc_14300_calculado - Iarc_2700_calculado) / 11.6) * (novo_Circuito.Voc - 14.3)) + Iarc_14300_calculado;

            Iarc_3 = ((Iarc_1 * (2.7 - novo_Circuito.Voc)) / 2.1) + ((Iarc_2 * (novo_Circuito.Voc - 0.6)) / 2.1);

            if (novo_Circuito.Voc > 0.6 && novo_Circuito.Voc <= 2.7)
            {
                Iarc = Iarc_3;
            }
            if (novo_Circuito.Voc > 2.7)
            {
                Iarc = Iarc_2;
            }

            //MessageBox.Show("Iarc Final: " + Iarc +" kA ");
            return (Iarc);
        }

        public int Verifica_Tipo(Circuito novo_Circuito)
        {
            int Tipo_involucro=0;
            if (novo_Circuito.Voc < 600 && novo_Circuito.Altura<508 && novo_Circuito.Largura<508 && novo_Circuito.Profundidade<=203.2)
            {
                Tipo_involucro = 1;
            }
            else
            {
                Tipo_involucro = 2;
            }

            return Tipo_involucro;
        }

        public double Calcula_Fator_Correcao(Circuito novo_Circuito, int Tipo_involucro)
        {

            double CF=1;
            double largura1=1;
            double altura1=1;
            double constante = 0.03937;
            double b1=0, b2=0, b3=0;

            
                if (novo_Circuito.Configuracao == "VCB")
                {
                    if (novo_Circuito.Largura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            largura1 = 20;
                        }
                        else
                        {
                            largura1 = constante * novo_Circuito.Largura;
                        }
                    }
                    else if (novo_Circuito.Largura >= 508 && novo_Circuito.Largura <= 660.4)
                    {
                        largura1 = constante * novo_Circuito.Largura;
                    }
                    else if (novo_Circuito.Largura > 660.4 && novo_Circuito.Largura <= 1244.6)
                    {
                        largura1 = (660.4 + ((novo_Circuito.Largura - 660.4) * ((novo_Circuito.Voc + 4) / 20))) / 25.4;
                    }
                    else
                    {
                        largura1 = (660.4 + ((1244.6 - 660.4) * ((novo_Circuito.Voc + 4) / 20))) / 25.4;
                    }

                    if (novo_Circuito.Altura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            altura1 = 20;
                        }
                        else
                        {
                            altura1 = constante * novo_Circuito.Altura;
                        }
                    }
                    else if (novo_Circuito.Altura >= 508 && novo_Circuito.Altura <= 660.4)
                    {
                        altura1 = constante * novo_Circuito.Altura;
                    }
                    else if (novo_Circuito.Altura > 660.4 && novo_Circuito.Altura <= 1244.6)
                    {
                        altura1 = constante * novo_Circuito.Altura;
                    }
                    else
                    {
                        altura1 = 49;
                    }
                }


                //para configuração VCBB
                if (novo_Circuito.Configuracao == "VCBB")
                {
                    if (novo_Circuito.Largura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            largura1 = 20;
                        }
                        else
                        {
                            largura1 = constante * novo_Circuito.Largura;
                        }
                    }
                    else if (novo_Circuito.Largura >= 508 && novo_Circuito.Largura <= 660.4)
                    {
                        largura1 = constante * novo_Circuito.Largura;
                    }
                    else if (novo_Circuito.Largura > 660.4 && novo_Circuito.Largura <= 1244.6)
                    {
                        largura1 = (660.4 + ((novo_Circuito.Largura - 660.4) * ((novo_Circuito.Voc + 10) / 24))) / 25.4;
                    }
                    else
                    {
                        largura1 = (660.4 + ((1244.6 - 660.4) * ((novo_Circuito.Voc + 10) / 24))) / 25.4;
                    }

                    if (novo_Circuito.Altura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            altura1 = 20;
                        }
                        else
                        {
                            altura1 = constante * novo_Circuito.Altura;
                        }
                    }
                    else if (novo_Circuito.Altura >= 508 && novo_Circuito.Altura <= 660.4)
                    {
                        altura1 = constante * novo_Circuito.Altura;
                    }
                    else if (novo_Circuito.Altura > 660.4 && novo_Circuito.Altura <= 1244.6)
                    {
                        altura1 = (660.4 + ((novo_Circuito.Altura - 660.4) * ((novo_Circuito.Voc + 10) / 24))) / 25.4;
                    }
                    else
                    {
                        altura1 = (660.4 + ((1244.6 - 660.4) * ((novo_Circuito.Voc + 10) / 24))) / 25.4;
                    }
                }


                //Para configuração HCB
                if (novo_Circuito.Configuracao == "HCB")
                {
                    if (novo_Circuito.Largura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            largura1 = 20;
                        }
                        else
                        {
                            largura1 = constante * novo_Circuito.Largura;
                        }
                    }
                    else if (novo_Circuito.Largura >= 508 && novo_Circuito.Largura <= 660.4)
                    {
                        largura1 = constante * novo_Circuito.Largura;
                    }
                    else if (novo_Circuito.Largura > 660.4 && novo_Circuito.Largura <= 1244.6)
                    {
                        largura1 = (660.4 + ((novo_Circuito.Largura - 660.4) * ((novo_Circuito.Voc + 10) / 22))) / 25.4;
                    }
                    else
                    {
                        largura1 = (660.4 + ((1244.6 - 660.4) * ((novo_Circuito.Voc + 10) / 22))) / 25.4;
                    }



                    if (novo_Circuito.Altura < 508)
                    {
                        if (Tipo_involucro == 2)
                        {
                            altura1 = 20;
                        }
                        else
                        {
                            altura1 = constante * novo_Circuito.Altura;
                        }
                    }
                    else if (novo_Circuito.Altura >= 508 && novo_Circuito.Altura <= 660.4)
                    {
                        altura1 = constante * novo_Circuito.Altura;
                    }
                    else if (novo_Circuito.Altura > 660.4 && novo_Circuito.Altura <= 1244.6)
                    {
                        altura1 = (660.4 + ((novo_Circuito.Altura - 660.4) * ((novo_Circuito.Voc + 10) / 22))) / 25.4;
                    }
                    else
                    {
                        altura1 = (660.4 + ((1244.6 - 660.4) * ((novo_Circuito.Voc + 10) / 22))) / 25.4;
                    //MessageBox.Show("Altura corrigida" + altura1);
                }
                }


                double EES = (largura1 + altura1) / 2;


                //Se o invólucro for Tipico
                if (Tipo_involucro == 2 && novo_Circuito.Configuracao != "VOA" && novo_Circuito.Configuracao != "HOA")
                {

                    for (int i = 1; i <= 3; i++)
                    {
                    
                        if (Table7.Cells[1 + i, 2].Value.ToString() == novo_Circuito.Configuracao)
                        {
                            b1 = Table7.Cells[1 + i, 3].Value;
                            b2 = Table7.Cells[1 + i, 4].Value;
                            b3 = Table7.Cells[1 + i, 5].Value;
                        }
                    }
                    CF = (b1 * EES * EES) + (b2 * EES) + b3;

                }

                //Se o invólucro for Raso
                if (Tipo_involucro == 1 && novo_Circuito.Configuracao != "VOA" && novo_Circuito.Configuracao != "HOA")
                {
                    for (int i = 1; i <= 3; i++)
                    {
                        if (Table7.Cells[4 + i, 2].Value.ToString() == novo_Circuito.Configuracao)
                        {
                            b1 = Table7.Cells[4 + i, 3].Value;
                            b2 = Table7.Cells[4 + i, 4].Value;
                            b3 = Table7.Cells[4 + i, 5].Value;
                        }
                    }
                    CF = 1 / ((b1 * EES * EES) + (b2 * EES) + b3);
                }
            
            
            //MessageBox.Show("Fator de Correção: " + CF);
            return CF;
        }

        public double Calcula_EImV600(float TIarc, Circuito novo_Circuito, double Iarc_600_calculado, double Iarc_calculado, double CF)
        {
            double EImV600 = 0;
            double expoente=0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table3.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table3.Cells[a, 1 + i].Value;
                    }
                }
            }
            expoente = k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_600_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[12] * Math.Log10(novo_Circuito.Distancia_trabalho)) + (k[13] * Math.Log10(Iarc_calculado)) + (Math.Log10(1 / CF));

            //MessageBox.Show("expoente: " + expoente + "\n TIarc" + TIarc);

            EImV600 = (12.552 / 50) * TIarc * Math.Pow(10, expoente);   //Resultado em J/cm²

            //MessageBox.Show("Energia Incidente: " + EImV600 / 4.184 + " Cal/cm²");

            return EImV600;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cBtpcorrente_TextChanged(object sender, EventArgs e)
        {
            // Verifica se o texto da cBtpcorrente corresponde ao valor igual a "CC"
            if (cBtpcorrente.Text == "CC")
            {
                //Limpa os campos que serão desabilitados
                cBConfig.SelectedIndex = -1;
                tBG.Text = "";
                tBLargura.Text = "";
                tBAltura.Text = "";
                tBProfundidade.Text = "";

                tBTIarcmin.Text = "";

                // Desabilita a cBConfig textBox a seguir se o texto for igual a "CC"
                cBConfig.Enabled = false;
                tBG.Enabled = false;
                tBTIarcmin.Enabled = false;
                tBLargura.Enabled = false;
                tBAltura.Enabled = false;
                tBProfundidade.Enabled = false;
                cBAmbiente.Enabled = true;
                tBD.Enabled = true;


            }
            else
            {
                if (ValidarTensao())
                {
                    if ((float.Parse("0" + tBVoc.Text)) <= 15)
                    {
                        // se o texto for igual a "AC"
                        //cBAmbiente.SelectedIndex = -1;
                        cBConfig.Enabled = true;
                        tBG.Enabled = true;
                        tBLargura.Enabled = true;
                        tBAltura.Enabled = true;
                        tBProfundidade.Enabled = true;
                        tBTIarcmin.Enabled = true;
                        //cBAmbiente.Enabled = false;
                    }
                }
            }
        }

        private void tBVoc_TextChanged(object sender, EventArgs e)
        {
            // Verifica se o valor da tBVoc for maior que o valor 15kV
            if (ValidarTensao())
            {
                if ((float.Parse("0" + tBVoc.Text)) > 15 && cBtpcorrente.Text == "AC")
                {
                    //Limpa os campos que serão desabilitados  
                    cBAmbiente.SelectedIndex = 0;
                    cBConfig.SelectedIndex = -1;         //seleciona ambiente aberto
                    tBG.Text = "";
                    tBLargura.Text = "";
                    tBAltura.Text = "";
                    tBProfundidade.Text = "";
                    tBTIarcmin.Text = "";
                    tBD.Text = "";

                    // Desabilita a cBConfig textBox a seguir se o valor da tBVoc for maior que o valor 15kV
                    cBConfig.Enabled = false;
                    tBG.Enabled = false;
                    tBLargura.Enabled = false;
                    tBAltura.Enabled = false;
                    tBProfundidade.Enabled = false;
                    tBTIarcmin.Enabled = false;
                    cBAmbiente.Enabled = false;
                    tBD.Enabled = false;
                }
                else
                {
                    if (cBtpcorrente.Text == "AC")
                    {                     // Habilita a cBConfig textBox a seguir se o valor da tBVoc for menor ou igual que 15kV
                        cBAmbiente.SelectedIndex = -1;
                        cBConfig.Enabled = true;
                        tBG.Enabled = true;
                        tBLargura.Enabled = true;
                        tBAltura.Enabled = true;
                        tBProfundidade.Enabled = true;
                        tBTIarcmin.Enabled = true;
                        cBAmbiente.Enabled = false;
                        tBD.Enabled = true;
                    }
                }
            }

        }

        public double Calcula_EImV2700(float TIarc, Circuito novo_Circuito, double Iarc_2700_calculado, double CF)
        {
            //pág 62
            double EImV2700 = 0;
            double expoente = 0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table4.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table4.Cells[a, 1 + i].Value;
                    }
                }
            }
            expoente = k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_2700_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[12] * Math.Log10(novo_Circuito.Distancia_trabalho)) + (k[13] * Math.Log10(Iarc_2700_calculado)) + (Math.Log10(1 / CF));

            EImV2700 = (12.552 / 50) * TIarc * Math.Pow(10, expoente);   //Resultado em J/cm²

            return EImV2700;
        }

        public double Calcula_EImV14300(float TIarc, Circuito novo_Circuito, double Iarc_14300_calculado, double CF)
        {
            
            double EImV14300 = 0;
            double expoente = 0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table5.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table5.Cells[a, 1 + i].Value;
                    }
                }
            }
            expoente = k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_14300_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[12] * Math.Log10(novo_Circuito.Distancia_trabalho)) + (k[13] * Math.Log10(Iarc_14300_calculado)) + (Math.Log10(1 / CF));

            EImV14300 = (12.552 / 50) * TIarc * Math.Pow(10, expoente);   //Resultado em J/cm²

            return EImV14300;
        }
                     
        public double Calcula_EI(Circuito novo_Circuito,double EImV600, double EImV2700, double EImV14300)
        {
            double EI=0;
            double E1, E2, E3;

            E1 = (((EImV2700 - EImV600) / 2.1) * (novo_Circuito.Voc - 2.7)) + EImV2700;
            E2 = (((EImV14300 - EImV2700) / 11.6) * (novo_Circuito.Voc - 14.3)) + EImV14300;
            E3 = ((E1 * (1.7 - novo_Circuito.Voc)) + (E2 * (novo_Circuito.Voc - 0.6))) / 2.1;

            if (novo_Circuito.Voc > 0.6 && novo_Circuito.Voc <= 2.7)
            {
                EI = E3;
            }
            if (novo_Circuito.Voc > 2.7)
            {
                EI = E2;
            }

            //MessageBox.Show("EI Final: " + EI +" J/cm² ");

            return EI;
        }

        public double Calcula_AFBmV600(float TIarc, Circuito novo_Circuito, double Iarc_600_calculado, double Iarc_calculado, double CF)
        {
            double AFBmV600 = 0;
            double expoente = 0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table3.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table3.Cells[a, 1 + i].Value;
                    }
                }
            }

            expoente = (k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_600_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[13] * Math.Log10(Iarc_calculado)) + (Math.Log10(1 / CF))-Math.Log10(20/TIarc))/(-k[12]);

            AFBmV600 = Math.Pow(10, expoente);      //Resultado em [mm]

            return AFBmV600;
        }

        public double Calcula_AFBmV2700(float TIarc, Circuito novo_Circuito, double Iarc_2700_calculado, double CF)
        {
            double AFBmV2700 = 0;
            double expoente = 0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table4.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table4.Cells[a, 1 + i].Value;
                    }
                }
            }

            expoente = (k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_2700_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[13] * Math.Log10(Iarc_2700_calculado)) + (Math.Log10(1 / CF)) - Math.Log10(20 / TIarc)) / (-k[12]);

            AFBmV2700 = Math.Pow(10, expoente);      //Resultado em [mm]

            return AFBmV2700;
        }

        public double Calcula_AFBmV14300(float TIarc, Circuito novo_Circuito, double Iarc_14300_calculado, double CF)
        {
            double AFBmV14300 = 0;
            double expoente = 0;
            double[] k = new double[14];
            double Ibf = novo_Circuito.Ibf;
            double Ibf2 = Ibf * Ibf;                    // Ibf^2
            double Ibf3 = Ibf2 * Ibf;                   // Ibf^3
            double Ibf4 = Ibf3 * Ibf;                   // Ibf^4
            double Ibf5 = Ibf4 * Ibf;                   // Ibf^5
            double Ibf6 = Ibf5 * Ibf;                   // Ibf^6
            double Ibf7 = Ibf6 * Ibf;                   // Ibf^7

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table5.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table5.Cells[a, 1 + i].Value;
                    }
                }
            }

            expoente = (k[1] + (k[2] * Math.Log10(novo_Circuito.Gap)) + ((k[3] * Iarc_14300_calculado) / ((k[4] * Ibf7) + (k[5] * Ibf6) + (k[6] * Ibf5) + (k[7] * Ibf4) + (k[8] * Ibf3) + (k[9] * Ibf2) + (k[10] * Ibf))) + (k[11] * Math.Log10(Ibf)) + (k[13] * Math.Log10(Iarc_14300_calculado)) + (Math.Log10(1 / CF)) - Math.Log10(20 / TIarc)) / (-k[12]);

            AFBmV14300 = Math.Pow(10, expoente);      //Resultado em [mm]

            return AFBmV14300;
        }

        public double Calcula_AFB(Circuito novo_Circuito, double AFBmV600, double AFBmV2700, double AFBmV14300)
        {
            double AFB = 0;
            double AFB1, AFB2, AFB3;

            AFB1 = (((AFBmV2700 - AFBmV600) / 2.1) * (novo_Circuito.Voc - 2.7)) + AFBmV2700;
            AFB2 = (((AFBmV14300 - AFBmV2700) / 11.6) * (novo_Circuito.Voc - 14.3)) + AFBmV14300;
            AFB3 = ((AFB1 * (1.7 - novo_Circuito.Voc)) + (AFB2 * (novo_Circuito.Voc - 0.6))) / 2.1;

            if (novo_Circuito.Voc > 0.6 && novo_Circuito.Voc <= 2.7)
            {
                AFB = AFB3;
            }
            if (novo_Circuito.Voc > 2.7)
            {
                AFB = AFB2;
            }

           // MessageBox.Show("AFB Final: " + AFB + " mm ");

            return AFB;
        }

        public double Iarcmin(Circuito novo_Circuito, double Iarc_calculado)
        {
            double Iarcmin = 0;
            double VarCf;
            double[] k = new double[8];
            double Voc = novo_Circuito.Voc;
            double Voc2 = Voc * Voc;                    // Voc^2
            double Voc3 = Voc2 * Voc;                   // Voc^3
            double Voc4 = Voc3 * Voc;                   // Voc^4
            double Voc5 = Voc4 * Voc;                   // Voc^5
            double Voc6 = Voc5 * Voc;                   // Voc^6

            for (int a = 1; a < 7; a++)
            {
                if (novo_Circuito.Configuracao == Table2.Cells[a, 1].Value)
                {
                    for (int i = 1; i < k.Length; i++)
                    {
                        k[i] = Table2.Cells[a, 1 + i].Value;
                    }
                }
            }

            VarCf = (k[1] * Voc6) + (k[2] * Voc5) + (k[3] * Voc4) + (k[4] * Voc3) + (k[5] * Voc2) + (k[6] * Voc) + k[7];

            Iarcmin = Iarc_calculado * (1 - (VarCf/2));

            return Iarcmin;
        }

        public void ATPVselecao()
        {
            float EI = float.Parse("0" + tBEI.Text);
            if (EI < 4)
            {
                //tBATPV.Text = "Categoria 1\r\nLinha 2\r\nLinha 3";
                tBATPV.Text = "Categoria 1\r\n" +
                    "Camisa e calça de manga comprida com classificação de arco\r\n" +
                    "Protetor facial com classificação de arco\r\n" +
                    "Óculos de segurança\r\n" +
                    "Capacete\r\n" +
                    "Proteção auditiva\r\n" +
                    "Luvas de couro resistentes";
                //Categoria 1
                //  Camisa e calça de manga comprida com classificação de arco ou macacão com classificação de arco
                //  Protetor facial com classificação de arcob ou capuz de terno de arco elétrico
                //  Óculos de segurança ou óculos de proteção
                //  Capacete
                //  Proteção auditiva
                //  Luvas de couro resistentes
            }
            else if (EI < 8)
            {
                //Categoria 2
                //  Camisa e calça de manga comprida com classificação de arco ou macacão com classificação de arco
                //  Capuz de traje de flash com classificação de arco ou escudo facial com classificação de arcob e balaclava com classificação de arco
                //  Capacete
                //  Óculos de segurança ou óculos de proteção
                //  Proteção auditiva
                //  Luvas de couro resistentes
                //  Calçado de couro
                tBATPV.Text = "Categoria 2\r\n" +
                    "Camisa e calça de manga comprida com classificação de arco\r\n" +
                    "Protetor facial com classificação de arco\r\n" +
                    "Óculos de segurança\r\n" +
                    "Capacete\r\n" +
                    "Proteção auditiva\r\n" +
                    "Luvas de couro resistentes\r\n" +
                    "Calçado de couro";

            }
            else if (EI < 25)
            {
                //Categoria 3
                //  Capuz de terno de arco elétrico com classificação de arco elétrico
                //  Luvas com classificação de arco
                //  Capacete
                //  Óculos de segurança ou óculos de proteção
                //  Proteção auditiva
                //  Calçado de couro
                tBATPV.Text = "Categoria 3\r\n" +
                   "Capuz de terno de arco elétrico com classificação de arco elétrico\r\n" +
                   "Luvas com classificação de arco\r\n" +
                   "Óculos de segurança\r\n" +
                   "Capacete\r\n" +
                   "Proteção auditiva\r\n" +
                   "Luvas de couro resistentes\r\n" +
                   "Calçado de couro";
            }
            else if (EI<40)
            {
                //Categoria 4
                //  Capuz de terno de arco elétrico com classificação de arco elétrico
                //  Luvas com classificação de arco
                //  Capacete
                //  Óculos de segurança ou óculos de segurança
                //  Proteção auditiva
                //  Calçado de couro
                tBATPV.Text = "Categoria 4\r\n" +
                  "Capuz de terno de arco elétrico com classificação de arco elétrico\r\n" +
                  "Luvas com classificação de arco\r\n" +
                  "Óculos de segurança\r\n" +
                  "Capacete\r\n" +
                  "Proteção auditiva\r\n" +
                  "Luvas de couro resis" +
                  "tentes\r\n" +
                  "Calçado de couro";
            }
            else
            {
                tBATPV.Text = "";
            }
        }

        private void CarregarPlanilha1()
        {
            try
            {
                pastaarquivo = app.Workbooks.Open(path);
                Table1 = pastaarquivo.Worksheets["Table1"];
                Table2 = pastaarquivo.Worksheets["Table2"];
                Table3 = pastaarquivo.Worksheets["Table3"];
                Table4 = pastaarquivo.Worksheets["Table4"];
                Table5 = pastaarquivo.Worksheets["Table5"];
                Table6 = pastaarquivo.Worksheets["Table6"];
                Table7 = pastaarquivo.Worksheets["Table7"];
                Table8 = pastaarquivo.Worksheets["Table8"];
                Table10 = pastaarquivo.Worksheets["Table10"];
                Table11 = pastaarquivo.Worksheets["Table11"];
                Table12 = pastaarquivo.Worksheets["Table12"];
            }
            catch (Exception exc)
            {
                MessageBox.Show("Falha: " + exc.Message);
            }
        }

        private void CarregarPlanilha2()
        {
            try
            {
                pasta_calculossalvos = app.Workbooks.Open(arquivo);
                Plan1 = pasta_calculossalvos.Worksheets["Plan1"];               
            }
            catch (Exception exc)
            {
                MessageBox.Show("Falha: " + exc.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            app.Quit();                         // sai da aplicação

            Table1 = null;
            Table2 = null;
            Table3 = null;
            Table4 = null;
            Table5 = null;
            Table6 = null;
            Table7 = null;
            Table8 = null;
            Table10 = null;
            Table11 = null;
            Table12 = null;
            Plan1 = null;
            pastaarquivo = null;
            pasta_calculossalvos = null;
            app = null;
        }

        private void cBConfig_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private bool ValidarTensao()
        {
            var msg = "";
            if (double.TryParse(tBVoc.Text, out _))
            { }
            else
            {
                // Se não for um número decimal, exibe uma mensagem ou executa outra ação
                msg += "O conteúdo está vazio ou não é um número.";
            }

            if (msg == "")
                return true;
            else
            {
                MessageBox.Show(msg, "Aviso",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

    }

    public class Circuito
    {
        public float Voc { get; private set; }
        public string Configuracao { get; private set; }
        public float Ibf { get; private set; }
        public float Gap { get; private set; }
        public float Distancia_trabalho { get; private set; }
        public float Largura { get; private set; }
        public float Altura { get; private set; }
        public float Profundidade { get; private set; }
        public string Nome { get; private set; }

        public Circuito(float voc, string configuracao, float ibf, float gap, float distancia_trabalho, float largura, float altura, float profundidade, string nome)
        {
            this.Voc = voc;
            this.Configuracao = configuracao;
            this.Ibf = ibf;
            this.Gap = gap;
            this.Distancia_trabalho = distancia_trabalho;
            this.Largura = largura;
            this.Altura = altura;
            this.Profundidade = profundidade;
            this.Nome = nome;
        }
    }

}